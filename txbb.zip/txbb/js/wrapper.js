window.web = {
	serverip: "http://192.168.0.176"
}
window.url = {
	register: web.serverip + ":8000/user/register",
	loginurl: web.serverip + ":8000/user/login",
	updheadurl: web.serverip + ":8001/res/updHead",
	voiceMsg: web.serverip + ":8001/res/voiceMsg",
	searchByUsername: web.serverip + ":8000/user/searchByUsername",
	friendsRequest: web.serverip + ":8002/friends/requestFriends",
	searchMyRequest: web.serverip + ":8002/friends/searchMyRequest",
	handleRequest: web.serverip + ":8002/friends/handleRequest",
	searchFriendsList: web.serverip + ":8002/friends/searchFriendsList",
	getServer: web.serverip + ":8003/chat/getServer",
	readMsg: web.serverip + ":8003/chat/readMsg",
	msgReceived: web.serverip + ":8003/chat/msgReceived",
	unReceivedMsgs: web.serverip + ":8003/chat/unReceivedMsgs"
}
window.util = {
	ajax: function(event){
		plus.nativeUI.showWaiting("加载中...");
		mui.ajax(event.url,{
						data: event.data,
						type: "post",
						timeout: 10000,
						dataType: "json",
						success: function(data){
							plus.nativeUI.closeWaiting();
							event.success(data);
						},
						error: function(){
							plus.nativeUI.closeWaiting();
							event.error();
						}
					})
	},
	getUser: function(){
		return JSON.parse(plus.storage.getItem("user"));
	},
	setUser: function(user){
		plus.storage.setItem("user",JSON.stringify(user))
	},
	removeUser: function(){
		plus.storage.removeItem("user");
	},
	setFriends: function(id,friends){
		plus.storage.setItem("friends_" + id,JSON.stringify(friends));
	},
	getFriends: function(id){
		return plus.storage.getItem("friends_" + id) ? JSON.parse(plus.storage.getItem("friends_" + id)) : null;
	},
	saveChatRecord: function(fid,wsMsg){
		var user = this.getUser();
		var record = this.getChatRecord(fid);
		if(!record){
			record = [];
		}
		record.push(wsMsg);
		var key = "record_" + user.id + "_" + fid;
		plus.storage.setItem(key,JSON.stringify(record));
		
	},
	getChatRecord: function(fid){
		var user = this.getUser();
		var key = "record_" + user.id + "_" + fid;
		var record = plus.storage.getItem(key);
		return (record == null) ? null : JSON.parse(record);
	},
	saveChatList: function(id,ul){
		plus.storage.setItem("chat_list_" + id,ul);
	},
	getChatList: function(id){
		return plus.storage.getItem("chat_list_" + id) ? plus.storage.getItem("chat_list_" + id) : null;
	}
}
