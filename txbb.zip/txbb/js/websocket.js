//连接websocket
var ws;

function connectServer(event) {
	//是否支持websocket
	if(window.WebSocket) {
		//获取websocket服务器地址
		util.ajax({
			url: url.getServer,
			success: function(data) {
				if(data.code == "8888" && data.data != "") {
					//websocket服务器获取成功,连接
					ws = new WebSocket("ws://" + data.data + "/txbb");
					ws.onopen = function() {
						//发送握手消息,让服务器确认关系
						sendObjectMsg(new WsMsg(1, null, null));
						//关闭重连,发送心跳
						clearTimeout(timeout);
						sendHeart();
						event.onOpen();
					};
					ws.onclose = function() {
						//连接关闭,关闭心跳,尝试重连
						clearTimeout(heart);
						reConnect(event);
						event.onClose();

					};
					ws.onerror = event.onError;
					ws.onmessage = function(result) {
						event.onMessage(result);
					};

				} else {
					//连接失败,尝试重连
					reConnect(event);
					mui.toast("获取websocket地址异常")
				}
			},
			error: function() {
				reConnect(event);
			}
		})
	} else {
		mui.toast("不支持websocket")
	}
}

//发送消息
function sendMsg(msg) {
	ws.send(msg);
}

//发送消息(封装的消息)
function sendObjectMsg(msgObj) {
	sendMsg(JSON.stringify(msgObj));
}

//重新连接,5S一次
var timeout;

function reConnect(event) {
	mui.toast("正在重连...")
	timeout = setTimeout(function() {
		connectServer(event);
	}, 5000)
}

//心跳,5S一次.服务端没收到心跳会断开和客户端的连接
var heart;

function sendHeart() {
	heart = setTimeout(function() {
		//		mui.toast("发送心跳...")
		sendObjectMsg(new WsMsg(2, null, null));
		sendHeart();
	}, 5000)
}

//与服务器通讯的消息封装
/**
 * 
 * @param {Object} type
 * @param {Object} toId
 * @param {Object} content
 * @param {Object} msgType
 */
var WsMsg = function(type, toId, content, msgType) {
	var user = util.getUser();
	this.fromId = user.id;
	this.toId = toId;
	/**
	 * 1 -握手
	 * 2 - 心跳
	 * 
	 * 100 - 强制下线
	 * 101 - 好友申请
	 * 102 - 单聊
	 */
	this.type = type;
	/**
	 * 消息内容类型 
	 * 1 - 文本
	 * 2 - 语音
	 * 3 - 图片
	 */
	this.content = content;
	this.msgType = msgType;
	this.uuid = plus.device.uuid;
}

//下线操作
function downLine() {
	mui.toast("您的账号已在其它设备登录,如非本人操作请尽快修改密码");
	util.removeUser();
	var index = plus.webview.getWebviewById("index.html");
	plus.webview.open("login.html", "login.html");
	index.close();
	//	ws.close();
}